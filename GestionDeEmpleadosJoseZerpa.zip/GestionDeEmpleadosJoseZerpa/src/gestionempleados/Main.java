package gestionempleados;

public class Main {
    public static void main(String[] args) {
        
        EmpleadosGUI.main(args);
    }
}
